#!/bin/bash
total=$(grep MemTotal /proc/meminfo | awk '{print $2}')
free=$(grep MemFree /proc/meminfo | awk '{print $2}')
buffers=$(grep Buffers /proc/meminfo | awk '{print $2}')
cached=$(grep "^Cached:" /proc/meminfo | awk '{print $2}')
sreclaimable=$(grep SReclaimable /proc/meminfo | awk '{print $2}')


used=$(( (total - free - buffers - cached - sreclaimable) / 1024 ))
total_mb=$(( total / 1024 ))


if [ $used -ge 1024 ]; then
    used_fmt="$(echo "scale=1; $used/1024" | bc)GB"
else
    used_fmt="${used}MB"
fi


if [ $total_mb -ge 1024 ]; then
    total_fmt="$(echo "scale=1; $total_mb/1024" | bc)GB"
else
    total_fmt="${total_mb}MB"
fi


echo "$used_fmt / $total_fmt"
